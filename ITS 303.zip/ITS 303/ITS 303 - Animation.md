---
tags:
  - subject
---
# Notes
[[Types of Animation]]


# Project
[[Flipbook Assignment]]