---
tags:
  - task
---

1. use a sticky note as a flipbook
2. draw and animate things inside that flipbook

**DEADLINE:** July 28, 2026
[[Projects]]